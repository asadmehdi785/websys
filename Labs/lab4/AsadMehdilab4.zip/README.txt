Asad Mehdi
Lab 4: JSON and AJAX

Contains: lab4.html, lab4.css, lab4.js, lab4.json, noalbum.png

Part 0: Setup
 - Confirmed that my folder is being served by Apache, everything is good for this part

Part 1: JSON
 - lab4.json contains the information for this part

Part 2: AJAX and jQuery
 - lab4.js contains the JavaScript for this part
 - Please take a look at lab4.js for explanation of the code