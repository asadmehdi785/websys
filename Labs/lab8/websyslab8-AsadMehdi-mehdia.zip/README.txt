Asad Mehdi

Lab #8: SQL

Part 0:
- New folder already created and all set

Part 1:
- Code for this part can be seen in "websyslab8.sql" file

Part 2:
- Code for questions 7 - 10 can be found in "commands.txt" file

Hope you have a nice day! :)