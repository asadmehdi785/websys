Name: Asad Mehdi
Lab 3: JavaScript and the Document Object Model

lab3.html contains the HTML for this lab. The only edits I made to this file were adding a <script> tag linking to my lab3.js file and changing the <link> tag to link to lab3.css.

My lab3.js file contains all the necessary code for this lab. It includes a getDepth function that is used for part 1, as well as mouseOver and mouseOut functions used for part 3. All the code will run inside of the window.onload function, which will run once the page has fully loaded. Pleae take a look at my lab3.js file for further details into my code.

I did not change the CSS in the lab3.css file at all, just changed the name from lab3Solution.css to lab3.css.

Have a nice day! :)